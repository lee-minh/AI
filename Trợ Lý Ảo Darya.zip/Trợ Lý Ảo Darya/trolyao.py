import speech_recognition
import pyttsx3
import subprocess
import webbrowser
from datetime import date, datetime
import time
from chucnang import open_webbrowser, wikipedia, weather, yearold, welcome_to_Darya, noi
import os


Darya_ear = speech_recognition.Recognizer()
Darya_mouth = pyttsx3.init()
Darya_brain = ""

age = yearold()
now = datetime.now()
hour = now.strftime("%H")

today=date.today()
day=today.strftime("%a %B %d, %Y")

welcome_to_Darya(hour)
while  True:

	with speech_recognition.Microphone() as mic:
		print("Darya: I'm Listening")
		Darya_ear.adjust_for_ambient_noise(mic)
		audio = Darya_ear.record(mic, duration=3)


	try:
		you = Darya_ear.recognize_google(audio, language='vi')
	except :
		you = "" 
	print("You: "+you) 

	print("Darya:....")

	if you == "":
		Darya_brain = "I can't hear you, try again"
	elif "date" in you or "Hôm nay ngày bao nhiêu" in you:
		Darya_brain = day
	elif "Open YouTube" in you or "Mở YouTube" in you:
		Darya_brain = "Youtube is open"
		print('Darya: '+Darya_brain)   
		Darya_mouth.say(Darya_brain)
		Darya_mouth.runAndWait()	
		webbrowser.open('http://youtube.com',autoraise = True)
		os.system("pause")
	elif "Open page" in you or "Mở trình duyệt" in you:
		Darya_brain = "What page you want to open?"
		Darya_mouth.runAndWait()
		print('Darya: '+Darya_brain)   
		Darya_mouth.say(Darya_brain)
		name_webbrowser = input()		
		open_webbrowser(name_webbrowser)
		os.system("pause")
	elif "time" in you or "Bây giờ là mấy giờ" in you: 
		now = datetime.now()
		Darya_brain = now.strftime("%H hours %M minutes %S seconds %p")
	elif "introduce yourself" in you:
		Darya_brain = str(f"My name is Darya, i was created on 10/6/2021 in Python programming language till now I {age} days old")   
	elif "open Chrome" in you or "Mở trình duyệt" in you :
		Darya_brain = "browser is open"
		print('Darya: '+Darya_brain)   
		Darya_mouth.say(Darya_brain)
		Darya_mouth.runAndWait()
		subprocess.call(["C:\Program Files\Google\Chrome\Application\chrome.exe"])
		Darya_brain = "What Web you want to open ?"
		print('Darya: '+Darya_brain)   
		Darya_mouth.say(Darya_brain)
		Darya_mouth.runAndWait()
		with speech_recognition.Microphone() as mic:
			print("Darya: I'm Listening")
			Darya_ear.adjust_for_ambient_noise(mic)
			audio = Darya_ear.record(mic, duration=4)

		print("Darya:....")

		try:
			you = Darya_ear.recognize_google(audio, language='vi')
		except:
			you = "" 
		print("You: "+you)  
		webbrowser.open_new_tab('http://{you}.com')
	elif "weather" in you or "thời tiết" in you:
		Darya_brain = "what city you want know?"
		print("Darya: "+Darya_brain)
		Darya_mouth.say(Darya_brain)
		Darya_mouth.runAndWait()
		with speech_recognition.Microphone() as mic:
			print("Darya: I'm Listening")
			Darya_ear.adjust_for_ambient_noise(mic)
			audio = Darya_ear.record(mic, duration=4)
		try:
			you = Darya_ear.recognize_google(audio,language='vi')
		except:
			you = "" 
		print("You: "+you) 
		Darya_brain = weather(you)
		if "lỗi" in Darya_brain:
			you = input("enter your name city again:")
			Darya_brain = weather(you)
			print("Darya:"+Darya_brain)
			Darya_mouth.say(Darya_brain)
			break
	elif "Wiki" in you:
		Darya_brain = "What you want to know?"
		print('Darya: '+Darya_brain)
		Darya_mouth.say(Darya_brain)
		Darya_mouth.runAndWait()
		with speech_recognition.Microphone() as mic:
			print("Darya: I'm Listening")
			Darya_ear.adjust_for_ambient_noise(mic)
			audio = Darya_ear.record(mic, duration=4)
			print("Robot:....")
		try:
			you = Darya_ear.recognize_google(audio, language='vi')
		except:
			you = "" 
		print("You: "+you) 
		wikipedia.search(you)
		a=wikipedia.page(you)
		text = a.content
		# noi(text)
		Darya_brain=(text)
		if you == "":
			Darya_brain = "I can't hear you, try again"	
	elif "bye" in you or "Turn off" in you :
		Darya_brain = "Goodbye sir"
		print('Darya: '+Darya_brain)
		Darya_mouth.say(Darya_brain)
		Darya_mouth.runAndWait()
		break
	else:
		robot_brain = "I'm fine thank you and you" 

	print('Darya: '+Darya_brain)   
	Darya_mouth.say(Darya_brain)
	Darya_mouth.runAndWait()
	

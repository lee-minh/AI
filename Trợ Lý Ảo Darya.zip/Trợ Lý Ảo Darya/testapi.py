import openai

openai.api_key = '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'

# Khởi tạo session hội thoại
conversation_history = [
    {"role": "system", "content": "Bạn là một lập trình viên AI trẻ, cá tính, nói chuyện kiểu Gen Z."}
]

def chat_with_gpt(user_input):
    # Thêm prompt người dùng vào history
    conversation_history.append({"role": "user", "content": user_input})
    
    # Gọi OpenAI API
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",  # hoặc "gpt-4" nếu bạn có quyền
        messages=conversation_history,
        temperature=0.7,
        max_tokens=1000
    )
    
    # Lấy kết quả và append vào history
    reply = response.choices[0].message["content"].strip()
    conversation_history.append({"role": "assistant", "content": reply})
    
    return reply

# CLI chat loop
if __name__ == "__main__":
    print("🤖 ChatGPT Bot đã sẵn sàng. Gõ 'exit' để thoát.\n")
    while True:
        user_input = input("👤 Bạn: ")
        if user_input.lower() in ["exit", "quit"]:
            print("👋 Tạm biệt nha!")
            break
        reply = chat_with_gpt(user_input)
        print("🤖 GPT:", reply, "\n")

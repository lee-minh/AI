import wikipedia
import requests
import json
from gtts import gTTS
from playsound import playsound
import os
from datetime import time, datetime, date
import webbrowser
import speech_recognition
import pyttsx3

Darya_ear = speech_recognition.Recognizer()
Darya_mouth = pyttsx3.init()
Darya_brain = ""
yearold = ()
language='vi'

def noi(text):  # Hàm nói
    print("Darya: {}".format(text))
    tts = gTTS(text=text, lang=language, slow=False)
    tts.save("audio.mp3")
    playsound("audio.mp3")
    os.remove("audio.mp3")
def yearold(): #hàm tính tuổi
	d0 = date.today()
	d1 = date(2021, 6, 10)
	delta = abs(d0 - d1)
	delta = delta.days
	return delta
wikipedia.set_lang("vi")
def weather(city):  #hàm thời tiết
	response=requests.get("https://api.openweathermap.org/data/2.5/weather?q={}&appid=5a7a7bb9e610f268ddc31c0aa02cca34".format(city))
	data = response.text
	jsondata = json.loads(data)
	if jsondata['cod'] != 404:
		y= jsondata['main']
		temp = int(y['temp']) - 273
		pressure = y['pressure']
		humidiy = y['humidity']
		x = jsondata['weather']
		description = x[0]['description']
		Darya_brain =str(city) + " hiện đang có " + str(description)+", Nhiệt độ là "+ str(temp)+" độ C, "+" Độ ẩm là "+str(humidiy)+"%"
	else :
		Darya_brain = "lỗi"
	return Darya_brain
def open_webbrowser(name_webbrowser):
	
	Darya_brain = f"{name_webbrowser} is open"
	print('Darya: '+Darya_brain)   
	Darya_mouth.say(Darya_brain)
	Darya_mouth.runAndWait()	
	webbrowser.open(f'http://{name_webbrowser}.com',autoraise = True)
def welcome_to_Darya(hour):
	if int(hour)>=6 and int(hour)<12:
		Darya_brain=("Good Morning sir, Welcome to Darya")	
		print('Darya: '+Darya_brain)   
		Darya_mouth.say(Darya_brain)
		Darya_mouth.runAndWait()
	elif int(hour)>=12 and int(hour)<18:
		Darya_brain=("Good Afternoon sir, Welcome to Darya")
		print('Darya: '+Darya_brain)   
		Darya_mouth.say(Darya_brain)
		Darya_mouth.runAndWait()
	elif int(hour)>=18 and int(hour)<24:
		Darya_brain=("Good Night sir, Welcome to Darya") 	
		print('Darya: '+Darya_brain)   
		Darya_mouth.say(Darya_brain)
		Darya_mouth.runAndWait()
